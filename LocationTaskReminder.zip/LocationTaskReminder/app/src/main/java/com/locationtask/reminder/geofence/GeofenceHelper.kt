package com.locationtask.reminder.geofence

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.locationtask.reminder.data.local.TaskEntity

class GeofenceHelper(private val context: Context) {

    companion object {
        private const val TAG = "GeofenceHelper"
        const val ACTION_GEOFENCE_EVENT = "com.locationtask.reminder.ACTION_GEOFENCE_EVENT"
    }

    private val geofencingClient: GeofencingClient =
        LocationServices.getGeofencingClient(context)

    private val geofencePendingIntent: PendingIntent by lazy {
        val intent = Intent(context, GeofenceBroadcastReceiver::class.java).apply {
            action = ACTION_GEOFENCE_EVENT
        }
        PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    @SuppressLint("MissingPermission")
    fun addGeofence(task: TaskEntity, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val geofence = buildGeofence(task)
        val request = buildGeofencingRequest(geofence)

        geofencingClient.addGeofences(request, geofencePendingIntent)
            .addOnSuccessListener {
                Log.d(TAG, "Geofence added for task: ${task.id}")
                onSuccess()
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Failed to add geofence for task: ${task.id}", exception)
                onFailure(exception)
            }
    }

    fun removeGeofence(taskId: Int, onSuccess: () -> Unit = {}, onFailure: (Exception) -> Unit = {}) {
        geofencingClient.removeGeofences(listOf(taskId.toString()))
            .addOnSuccessListener {
                Log.d(TAG, "Geofence removed for task: $taskId")
                onSuccess()
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Failed to remove geofence for task: $taskId", exception)
                onFailure(exception)
            }
    }

    @SuppressLint("MissingPermission")
    fun registerAllGeofences(
        tasks: List<TaskEntity>,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        val activeTasks = tasks.filter { it.isActive }
        if (activeTasks.isEmpty()) return

        val geofences = activeTasks.map { buildGeofence(it) }
        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(geofences)
            .build()

        geofencingClient.addGeofences(request, geofencePendingIntent)
            .addOnSuccessListener {
                Log.d(TAG, "All geofences registered: ${activeTasks.size}")
                onSuccess()
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Failed to register all geofences", exception)
                onFailure(exception)
            }
    }

    private fun buildGeofence(task: TaskEntity): Geofence {
        return Geofence.Builder()
            .setRequestId(task.id.toString())
            .setCircularRegion(task.latitude, task.longitude, task.radius)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
            .setLoiteringDelay(500)
            .build()
    }

    private fun buildGeofencingRequest(geofence: Geofence): GeofencingRequest {
        return GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(geofence)
            .build()
    }
}
