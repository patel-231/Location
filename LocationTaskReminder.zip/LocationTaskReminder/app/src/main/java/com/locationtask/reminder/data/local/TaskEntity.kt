package com.locationtask.reminder.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val radius: Float = 100f,  // meters
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
