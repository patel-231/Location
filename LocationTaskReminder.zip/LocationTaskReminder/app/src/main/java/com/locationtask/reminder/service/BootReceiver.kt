package com.locationtask.reminder.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.locationtask.reminder.data.repository.TaskRepository
import com.locationtask.reminder.geofence.GeofenceHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Re-registers all geofences after device reboot,
 * since geofences are cleared when the device restarts.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d(TAG, "Boot completed - re-registering geofences")
            reRegisterGeofences(context)
        }
    }

    private fun reRegisterGeofences(context: Context) {
        val repository = TaskRepository(context)
        val geofenceHelper = GeofenceHelper(context)

        CoroutineScope(Dispatchers.IO).launch {
            val tasks = repository.getAllTasksSync()
            Log.d(TAG, "Re-registering ${tasks.size} geofences after boot")

            geofenceHelper.registerAllGeofences(
                tasks,
                onSuccess = { Log.d(TAG, "Geofences re-registered successfully") },
                onFailure = { e -> Log.e(TAG, "Failed to re-register geofences", e) }
            )
        }
    }
}
