package com.locationtask.reminder.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.locationtask.reminder.data.local.TaskEntity
import com.locationtask.reminder.databinding.ItemTaskBinding
import java.text.SimpleDateFormat
import java.util.*

class TaskAdapter(
    private val onDeleteClick: (TaskEntity) -> Unit,
    private val onToggleActive: (TaskEntity) -> Unit
) : ListAdapter<TaskEntity, TaskAdapter.TaskViewHolder>(DIFF_CALLBACK) {

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<TaskEntity>() {
            override fun areItemsTheSame(oldItem: TaskEntity, newItem: TaskEntity) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: TaskEntity, newItem: TaskEntity) =
                oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TaskViewHolder(private val binding: ItemTaskBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(task: TaskEntity) {
            binding.apply {
                tvTaskTitle.text = task.title
                tvTaskDescription.text = task.description
                tvLocation.text = "📍 ${String.format("%.5f", task.latitude)}, ${String.format("%.5f", task.longitude)}"
                tvRadius.text = "Radius: ${task.radius.toInt()}m"

                val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                tvCreatedAt.text = "Added: ${dateFormat.format(Date(task.createdAt))}"

                switchActive.isChecked = task.isActive
                switchActive.setOnCheckedChangeListener(null)
                switchActive.setOnCheckedChangeListener { _, _ ->
                    onToggleActive(task)
                }

                ivStatusIndicator.setImageResource(
                    if (task.isActive) android.R.drawable.presence_online
                    else android.R.drawable.presence_offline
                )

                btnDelete.setOnClickListener { onDeleteClick(task) }
            }
        }
    }
}
