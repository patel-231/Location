package com.locationtask.reminder.data.repository

import android.content.Context
import androidx.lifecycle.LiveData
import com.locationtask.reminder.data.local.TaskDao
import com.locationtask.reminder.data.local.TaskDatabase
import com.locationtask.reminder.data.local.TaskEntity

class TaskRepository(context: Context) {

    private val taskDao: TaskDao = TaskDatabase.getDatabase(context).taskDao()

    val allTasks: LiveData<List<TaskEntity>> = taskDao.getAllTasks()

    suspend fun getAllTasksSync(): List<TaskEntity> = taskDao.getAllTasksSync()

    suspend fun getTaskById(id: Int): TaskEntity? = taskDao.getTaskById(id)

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.updateTask(task)

    suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

    suspend fun deleteTaskById(id: Int) = taskDao.deleteTaskById(id)

    suspend fun setTaskActive(id: Int, isActive: Boolean) = taskDao.setTaskActive(id, isActive)
}
