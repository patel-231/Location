package com.locationtask.reminder.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.locationtask.reminder.data.local.TaskEntity
import com.locationtask.reminder.data.repository.TaskRepository
import com.locationtask.reminder.geofence.GeofenceHelper
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TaskRepository(application)
    private val geofenceHelper = GeofenceHelper(application)

    val allTasks: LiveData<List<TaskEntity>> = repository.allTasks

    fun addTask(
        title: String,
        description: String,
        latitude: Double,
        longitude: Double,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        viewModelScope.launch {
            val task = TaskEntity(
                title = title,
                description = description,
                latitude = latitude,
                longitude = longitude
            )
            val taskId = repository.insertTask(task)
            val savedTask = task.copy(id = taskId.toInt())

            geofenceHelper.addGeofence(
                savedTask,
                onSuccess = {
                    viewModelScope.launch { onSuccess() }
                },
                onFailure = { e ->
                    viewModelScope.launch {
                        onFailure("Task saved but geofence failed: ${e.message}")
                    }
                }
            )
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            geofenceHelper.removeGeofence(task.id)
            repository.deleteTask(task)
        }
    }

    fun toggleTaskActive(task: TaskEntity) {
        viewModelScope.launch {
            val newActiveState = !task.isActive
            repository.setTaskActive(task.id, newActiveState)
            if (newActiveState) {
                val updatedTask = task.copy(isActive = true)
                geofenceHelper.addGeofence(updatedTask, {}, {})
            } else {
                geofenceHelper.removeGeofence(task.id)
            }
        }
    }
}
