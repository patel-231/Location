package com.locationtask.reminder.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofenceStatusCodes
import com.google.android.gms.location.GeofencingEvent
import com.locationtask.reminder.data.repository.TaskRepository
import com.locationtask.reminder.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GeofenceBroadcastReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "GeofenceReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent) ?: return

        if (geofencingEvent.hasError()) {
            val errorMessage = GeofenceStatusCodes.getStatusCodeString(geofencingEvent.errorCode)
            Log.e(TAG, "Geofence error: $errorMessage")
            return
        }

        val geofenceTransition = geofencingEvent.geofenceTransition

        if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
            val triggeringGeofences = geofencingEvent.triggeringGeofences ?: return

            triggeringGeofences.forEach { geofence ->
                val taskId = geofence.requestId.toIntOrNull() ?: return@forEach
                Log.d(TAG, "Geofence entered for task: $taskId")
                handleGeofenceEntry(context, taskId)
            }
        }
    }

    private fun handleGeofenceEntry(context: Context, taskId: Int) {
        val repository = TaskRepository(context)

        CoroutineScope(Dispatchers.IO).launch {
            val task = repository.getTaskById(taskId)
            if (task != null && task.isActive) {
                Log.d(TAG, "Sending notification for task: ${task.title}")
                NotificationHelper.sendTaskNotification(
                    context,
                    task.id,
                    task.title,
                    task.description
                )
            } else {
                Log.w(TAG, "Task $taskId not found or inactive")
            }
        }
    }
}
