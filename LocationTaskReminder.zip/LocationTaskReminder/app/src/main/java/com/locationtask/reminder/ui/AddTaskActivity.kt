package com.locationtask.reminder.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.locationtask.reminder.databinding.ActivityAddTaskBinding
import com.locationtask.reminder.service.LocationService
import kotlinx.coroutines.launch

class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding
    private val viewModel: TaskViewModel by viewModels()
    private val locationService by lazy { LocationService(this) }

    private var currentLatitude: Double? = null
    private var currentLongitude: Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Add Location Task"

        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnUseCurrentLocation.setOnClickListener {
            fetchCurrentLocation()
        }

        binding.btnSaveTask.setOnClickListener {
            saveTask()
        }
    }

    private fun fetchCurrentLocation() {
        if (!locationService.hasLocationPermission()) {
            Toast.makeText(this, "Location permission not granted. Please allow it in Settings.", Toast.LENGTH_LONG).show()
            return
        }

        binding.progressLocation.visibility = View.VISIBLE
        binding.btnUseCurrentLocation.isEnabled = false
        binding.tvLocationStatus.text = "Fetching location..."

        lifecycleScope.launch {
            val location = locationService.getCurrentLocation()

            binding.progressLocation.visibility = View.GONE
            binding.btnUseCurrentLocation.isEnabled = true

            if (location != null) {
                currentLatitude = location.latitude
                currentLongitude = location.longitude

                binding.etLatitude.setText(String.format("%.7f", location.latitude))
                binding.etLongitude.setText(String.format("%.7f", location.longitude))
                binding.tvLocationStatus.text = "✅ Location captured: ${String.format("%.5f", location.latitude)}, ${String.format("%.5f", location.longitude)}"
                binding.tvLocationAccuracy.text = "Accuracy: ±${location.accuracy.toInt()}m"
                binding.tvLocationAccuracy.visibility = View.VISIBLE
            } else {
                binding.tvLocationStatus.text = "❌ Could not get location. Try again."
                Toast.makeText(this@AddTaskActivity, "Failed to get location. Make sure GPS is enabled.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveTask() {
        val title = binding.etTaskTitle.text.toString().trim()
        val description = binding.etTaskDescription.text.toString().trim()
        val latText = binding.etLatitude.text.toString().trim()
        val lngText = binding.etLongitude.text.toString().trim()

        // Validation
        if (title.isEmpty()) {
            binding.tilTaskTitle.error = "Task title is required"
            return
        } else {
            binding.tilTaskTitle.error = null
        }

        if (description.isEmpty()) {
            binding.tilTaskDescription.error = "Task description is required"
            return
        } else {
            binding.tilTaskDescription.error = null
        }

        val latitude = latText.toDoubleOrNull()
        val longitude = lngText.toDoubleOrNull()

        if (latitude == null || longitude == null) {
            Toast.makeText(this, "Please use current location or enter valid coordinates", Toast.LENGTH_LONG).show()
            return
        }

        if (latitude < -90 || latitude > 90) {
            binding.tilLatitude.error = "Latitude must be between -90 and 90"
            return
        }

        if (longitude < -180 || longitude > 180) {
            binding.tilLongitude.error = "Longitude must be between -180 and 180"
            return
        }

        // Show loading
        binding.btnSaveTask.isEnabled = false
        binding.btnSaveTask.text = "Saving..."

        viewModel.addTask(
            title = title,
            description = description,
            latitude = latitude,
            longitude = longitude,
            onSuccess = {
                runOnUiThread {
                    Toast.makeText(this, "✅ Task saved! You'll be reminded when you arrive.", Toast.LENGTH_LONG).show()
                    finish()
                }
            },
            onFailure = { message ->
                runOnUiThread {
                    binding.btnSaveTask.isEnabled = true
                    binding.btnSaveTask.text = "Save Task"
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    // Still finish if task was saved to DB even if geofence had issues
                    if (message.contains("Task saved")) {
                        finish()
                    }
                }
            }
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
