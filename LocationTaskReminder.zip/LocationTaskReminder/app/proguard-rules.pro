# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.locationtask.reminder.data.local.** { *; }
-keep class com.locationtask.reminder.geofence.** { *; }
